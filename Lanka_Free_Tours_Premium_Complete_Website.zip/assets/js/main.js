const CONFIG={whatsapp:"94762131020",email:"info@lankafreetours.com"};
function whatsappUrl(message){return `https://wa.me/${CONFIG.whatsapp}?text=${encodeURIComponent(message||"Hello Lanka Free Tours! I'd like to plan a trip to Sri Lanka.")}`;}
document.addEventListener('DOMContentLoaded',()=>{
 const toggle=document.querySelector('.menu'),nav=document.querySelector('.links');
 if(toggle&&nav)toggle.addEventListener('click',()=>{nav.classList.toggle('open');toggle.setAttribute('aria-expanded',nav.classList.contains('open')?'true':'false');});
 document.querySelectorAll('[data-wa]').forEach(a=>{a.href=whatsappUrl(a.dataset.msg);a.target='_blank';a.rel='noopener';});
 document.querySelectorAll('form[data-inquiry]').forEach(form=>form.addEventListener('submit',e=>{e.preventDefault();const fd=new FormData(form);const lines=["Hello Lanka Free Tours! I'd like to enquire about a Sri Lanka trip."];for(const [k,v] of fd.entries())if(String(v).trim())lines.push(`${k}: ${v}`);window.open(whatsappUrl(lines.join('\n')),'_blank','noopener');}));
});