LANKA FREE TOURS – PREMIUM WEBSITE

Upload the contents of this folder to your Hostinger public_html directory. Keep the assets folder and all HTML files in the same structure.

Contact details configured:
WhatsApp: +94 76 213 1020
Email: info@lankafreetours.com
Domain: https://lankafreetours.com

Forms prepare an enquiry in WhatsApp; visitors review and send the message themselves. No server-side form storage is configured.

IMPORTANT BEFORE GOING LIVE:
- Replace sample stock photography with your own licensed/original photos.
- Confirm all suggested itineraries, inclusions, rates and business claims. No fixed prices are published.
- Test every page and WhatsApp link on mobile and desktop.
- Configure Google Analytics 4 and Google Ads conversion tracking after deployment.
- Enable SSL and verify the sitemap in Google Search Console.
